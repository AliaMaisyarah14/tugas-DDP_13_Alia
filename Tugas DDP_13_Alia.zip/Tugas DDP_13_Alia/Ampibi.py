from Animal import Animal

# Class Ampibi mewarisi class Animal
class Ampibi(Animal):
    def __init__(self, name, makanan, hidup, berkembang_biak, jenis_air, bernapas):
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.jenis_air = jenis_air
        self.bernapas = bernapas

    def info_Ampibi(self):
        # Menampilkan informasi dari class Animal, kemudian tambahan dari Ampibi
        super().info_Animal()
        print(f"Jenis Air          : {self.jenis_air}")
        print(f"Bernapas dengan    : {self.bernapas}")

# Membuat objek Ampibi
katak = Ampibi("Katak", "Serangga", "Dua alam", "Bertelur", "Air Tawar", "Kulit dan Paru-paru")
katak.info_Ampibi()
