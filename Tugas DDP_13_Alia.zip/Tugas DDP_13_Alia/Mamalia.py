from Animal import Animal

class Mamalia(Animal):
    def __init__(self, name, makanan, hidup, berkembang_biak, ukuran_tubuh, jenis_kulit):
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.ukuran_tubuh = ukuran_tubuh
        self.jenis_kulit = jenis_kulit

    def info_Mamalia(self):
        # Menampilkan informasi dari parent class
        super().info_Animal()
        print(f"Ukuran Tubuh       : {self.ukuran_tubuh}")
        print(f"Jenis Kulit        : {self.jenis_kulit}")

# Membuat objek Mamalia
gajah = Mamalia("Gajah", "Tumbuhan", "Darat", "Melahirkan", "Sangat Besar", "Sedikit Berbulu")
gajah.info_Mamalia()
print("===================================================")

kucing = Mamalia("Kucing", "Hewan", "Darat", "Melahirkan", "Kecil", "Berbulu")
kucing.info_Mamalia()
print("===================================================")

kelinci = Mamalia("Kelinci", "Tumbuhan", "Darat", "Melahirkan", "Kecil", "Berbulu")
kelinci.info_Mamalia()
