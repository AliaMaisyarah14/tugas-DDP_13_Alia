class Animal:
    """
    Class Animal merepresentasikan hewan dengan properti dasar: nama, makanan, tempat hidup, dan cara berkembang biak.
    """
    def __init__(self, name, makanan, hidup, berkembang_biak):
        self.name = name
        self.makanan = makanan
        self.hidup = hidup
        self.berkembang_biak = berkembang_biak
    
    def info_Animal(self):
        """
        Menampilkan informasi tentang hewan.
        """
        print(f"Nama Hewan       : {self.name}")
        print(f"Makanannya       : {self.makanan}")
        print(f"Hidup di         : {self.hidup}")
        print(f"Berkembang biak  : {self.berkembang_biak}")

# Contoh objek hewan
kucing = Animal("Kucing", "Daging", "Rumah", "Melahirkan")
kucing.info_Animal()
