from Animal import Animal

class Carnivora(Animal):
    def __init__(self, name, makanan, hidup, berkembang_biak, ukuran_tubuh, jenis_kulit):
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.ukuran_tubuh = ukuran_tubuh
        self.jenis_kulit = jenis_kulit

    def info_Carnivora(self):
        # Menampilkan informasi dari parent class
        super().info_Animal()
        print(f"Ukuran Tubuh      : {self.ukuran_tubuh}")
        print(f"Jenis Kulit       : {self.jenis_kulit}")

# Membuat objek Carnivora
harimau = Carnivora("Harimau Sumatera", "Daging", "Darat", "Melahirkan", "Sangat Besar", "Sedikit Berbulu")
harimau.info_Carnivora()
print("===================================================")

ular = Carnivora("Ular Piton", "Daging", "Darat", "Bertelur", "Sedang", "Bersisik")
ular.info_Carnivora()
print("===================================================")

beruang = Carnivora("Beruang Kutub", "Daging", "Darat", "Melahirkan", "Besar", "Berbulu")
beruang.info_Carnivora()
